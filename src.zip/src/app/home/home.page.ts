import { Component, OnInit } from '@angular/core';
import { ProdukService } from '../produk';
import { TransactionService } from '../transaction';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: false
})
export class HomePage implements OnInit {

  constructor(
    private produkService: ProdukService,
    private transaksiService: TransactionService
  ) { }

  ngOnInit() {
    //this.loadDataDashboard();
  }

  ionViewWillEnter() {
    //this.loadDataDashboard();
  }

  /*loadDataDashboard() {
    this.jumlahProduk = this.produkService.getJumlahProduk();
    this.totalTransaksiHariIni = this.transaksiService.getTotalTransaksiHariIni();
    this.produkTerlaris = this.produkService.getProdukTerlaris();
  }
    */

  get jumlahProduk(): number {
    return this.produkService.getJumlahProduk();
  }

  get totalTransaksiHariIni(): number {
    return this.transaksiService.getTotalTransaksiHariIni();
  }
  get produkTerlaris(): string {
    return this.produkService.getProdukTerlaris();
  }
  
}